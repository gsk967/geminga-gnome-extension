# Geminga Gnome Extension
> This extension is show the real time crypto coin prices from `osmosis api`


# Installation
```bash
$ bash install.sh

> X11 Press alt-f2, type r, press Enter to restart the GNOME shell.
> Wayland Logout and re-login.
```

# Thanks for real time crypto coin prices from osmosis-labs
> API : https://api-osmosis.imperator.co/tokens/v1/all

# Thanks for icons from osmosis-labs
> Github: https://github.com/osmosis-labs/assetlists.git

