rm gsk967@github.com.shell-extension.zip
zip -r gsk967@github.com.shell-extension.zip .
gnome-extensions uninstall gsk967@github.com
gnome-extensions install gsk967@github.com.shell-extension.zip